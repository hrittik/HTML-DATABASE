
<form action="loguser.php" method="post">
		<br>
		User Name:<input type="text" name="un"  /><br/><br/>
		
		Password   :<input type="password" name="pw"/><br/><br/>
		<input type="submit" name="submit" />
</form>

