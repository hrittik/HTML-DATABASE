<!doctype html>
<html>
	<head>
		<title>Registration Form</title>
	</head>
	
	<body>
		<br>
		<br>
		<br>
		
		<h2 align=center>Registration</h2>
		<br>
		<form name="Registration" method="post" action="#">
			<table align=center>
				<tr>
					<th align=left>ID</th>
					<th>:</th>
					<th><input type="text" name="regId"></th>
				</tr>
				
				<tr>
					<th align=left>Password</th>
					<th>:</th>
					<th><input type="text" name="passId"></th>
				</tr>
				
				
				
				
				<tr>
					<th align=left><br><input type="submit" name="submit" ></th>
					<th align=right><br><input type="reset" name="reset" ></th>
				</tr>
				
				
				
				
			</table>
			
			<?php
/**
 * Created by PhpStorm.
 * User: mdsae
 * Date: 11-Jun-18
 * Time: 9:37 PM
 */

		require 'config.php';
		$head=$_POST['regId'];
		$data=$_POST['passId'];
		$statement="insert into login_table(id,password) values ('$head','$data')";

	if(mysqli_query($conn,$statement))
	{
		header('location:home.php');
	}
	else
	{mysqli_error($conn);}

		mysqli_close($conn);
		?>
			
			
			
		</form>
	</body>
</html>