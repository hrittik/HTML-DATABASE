<?php
if(isset($_POST['Print'])){
    //including the database connection file
    include("config.php");
    //connect_db();
//getting id of the data from url
    $id = $_GET['id'];
	$head=$_POST['heading'];
    $data=$_POST['newsbody'];
	//echo $head;
	
	$statement="update test set heading='$head',summertext='$data' where id=$id";
//deleting the row from table // actually not deleting it just unlinking from the result
    $result = mysqli_query($conn,$statement);
	$timeUpdate = "update test set Updatetime=now() where id='$id'";
    mysqli_query($conn,$timeUpdate);
	//close_db();
//redirecting to the display page (listdata.php in our case)
   header("Location:listdata.php");
    
}
?>	
<head>
    <title>News Site</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="summernote.css" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="summernote.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<div class="container">
   <!-- <center><h1> <span class="label label-default">Summernote data formatter</span></h1></center>-->
    <form name="summernote" method="post" >
		News Headline:<br/><input type="text" class="form-control" name="heading"/><br/>
        News Body:<br/><textarea name="newsbody" id="summernote" class="summernote"></textarea><br/>
        <input type="submit" name="Print" class="btn btn-success" value="Update"/>
    </form>
</div>
<script>
    $(document).ready(function() {
        $('#summernote').summernote();
    });
</script>
</head>
