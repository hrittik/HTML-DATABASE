<?php
session_start(); //start the PHP_session function 

          require 'config.php';
			$u = $_POST['un'];
			$p = $_POST['pw'];
            $statement="select * from login_table where id='$u' and password='$p'";
            $result = mysqli_query($conn, $statement);

            if (mysqli_num_rows($result) > 0)
            {
                while($row = mysqli_fetch_assoc($result))
                {
                    header("location:setdata.php");
					$_SESSION['user']=$_POST['un'];
					$_SESSION['pass']=$p;
                }
            }
            else
            {
                 header("location:login.php");
                
            }

    /*   if ($u == $_POST['un'] && $p==$_POST['pw']){
        $_SESSION['un'] = $u;
        header("location:home2.php");
       
    }

	else{
        header("location:login.php?invalid=true");
    }
	*/


?>